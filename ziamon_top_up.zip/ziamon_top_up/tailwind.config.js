module.exports = {
  content: ["./pages/*.{html,js}", "./index.html", "./js/*.js"],
  theme: {
    extend: {
      colors: {
        // Primary Colors - Electric Blue Theme
        primary: {
          50: "#EFF6FF", // blue-50
          100: "#DBEAFE", // blue-100
          500: "#3B82F6", // blue-500
          600: "#0066FF", // custom electric blue
          700: "#1D4ED8", // blue-700
          900: "#1E3A8A", // blue-900
          DEFAULT: "#0066FF", // custom electric blue
        },
        // Secondary Colors - Deep Navy Theme
        secondary: {
          50: "#F8FAFC", // slate-50
          100: "#F1F5F9", // slate-100
          200: "#E2E8F0", // slate-200
          600: "#475569", // slate-600
          700: "#334155", // slate-700
          800: "#1E293B", // slate-800
          900: "#1A1D29", // custom deep navy
          DEFAULT: "#1A1D29", // custom deep navy
        },
        // Accent Colors - Vibrant Orange Theme
        accent: {
          50: "#FFF7ED", // orange-50
          100: "#FFEDD5", // orange-100
          500: "#FF6B35", // custom vibrant orange
          600: "#EA580C", // orange-600
          700: "#C2410C", // orange-700
          DEFAULT: "#FF6B35", // custom vibrant orange
        },
        // Background Colors
        background: "#F8FAFC", // slate-50
        surface: "#FFFFFF", // white
        // Text Colors
        text: {
          primary: "#1E293B", // slate-800
          secondary: "#64748B", // slate-500
        },
        // Status Colors
        success: {
          50: "#ECFDF5", // emerald-50
          100: "#D1FAE5", // emerald-100
          500: "#00D084", // custom gaming green
          600: "#059669", // emerald-600
          DEFAULT: "#00D084", // custom gaming green
        },
        warning: {
          50: "#FFFBEB", // amber-50
          100: "#FEF3C7", // amber-100
          500: "#F59E0B", // amber-500
          DEFAULT: "#F59E0B", // amber-500
        },
        error: {
          50: "#FEF2F2", // red-50
          100: "#FEE2E2", // red-100
          500: "#EF4444", // red-500
          DEFAULT: "#EF4444", // red-500
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        inter: ['Inter', 'sans-serif'],
        gaming: ['Orbitron', 'monospace'],
        orbitron: ['Orbitron', 'monospace'],
      },
      fontSize: {
        'gaming-xl': ['1.5rem', { lineHeight: '2rem', fontWeight: '700' }],
        'gaming-2xl': ['2rem', { lineHeight: '2.5rem', fontWeight: '700' }],
        'gaming-3xl': ['2.5rem', { lineHeight: '3rem', fontWeight: '700' }],
      },
      boxShadow: {
        'gaming': '0 4px 20px rgba(0, 102, 255, 0.15)',
        'gaming-accent': '0 4px 20px rgba(255, 107, 53, 0.15)',
        'gaming-success': '0 4px 20px rgba(0, 208, 132, 0.15)',
        'gaming-hover': '0 6px 25px rgba(0, 102, 255, 0.25)',
        'gaming-accent-hover': '0 6px 25px rgba(255, 107, 53, 0.25)',
      },
      borderRadius: {
        'gaming': '8px',
        'gaming-sm': '4px',
      },
      animation: {
        'achievement-pulse': 'achievement-pulse 2s ease-in-out infinite',
        'celebration': 'celebration 400ms ease-out',
        'gaming-glow': 'gaming-glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        'achievement-pulse': {
          '0%, 100%': {
            boxShadow: '0 0 0 0 rgba(0, 208, 132, 0.4)',
          },
          '50%': {
            boxShadow: '0 0 0 10px rgba(0, 208, 132, 0)',
          },
        },
        'celebration': {
          '0%': { transform: 'scale(1)' },
          '50%': { transform: 'scale(1.05)' },
          '100%': { transform: 'scale(1)' },
        },
        'gaming-glow': {
          '0%': {
            boxShadow: '0 0 5px rgba(0, 102, 255, 0.5)',
          },
          '100%': {
            boxShadow: '0 0 20px rgba(0, 102, 255, 0.8)',
          },
        },
      },
      transitionDuration: {
        '300': '300ms',
        '400': '400ms',
      },
      transitionTimingFunction: {
        'gaming': 'cubic-bezier(0.4, 0, 0.2, 1)',
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
    },
  },
  plugins: [],
}